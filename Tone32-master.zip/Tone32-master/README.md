Tone library for ESP32

Warning! The tone function has been incorporated into the arduino-esp32 core in version 2.0.3.  Do not use this code in newer releases!
